﻿namespace QuanLyBanHang.Forms
{
    partial class fAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tbpDoanhthu = new System.Windows.Forms.TabPage();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.btnthongke = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.tbpBanh = new System.Windows.Forms.TabPage();
            this.panel6 = new System.Windows.Forms.Panel();
            this.lblVoucher = new System.Windows.Forms.Label();
            this.txtVoucher = new System.Windows.Forms.TextBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.nudSoluong = new System.Windows.Forms.NumericUpDown();
            this.lblSoluong = new System.Windows.Forms.Label();
            this.btnXoa = new System.Windows.Forms.Button();
            this.btnSua = new System.Windows.Forms.Button();
            this.btnThem = new System.Windows.Forms.Button();
            this.btnXem = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.nudGia = new System.Windows.Forms.NumericUpDown();
            this.LblGia = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.lblTenbanh = new System.Windows.Forms.Label();
            this.txtName = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lblId = new System.Windows.Forms.Label();
            this.txtId = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.tbpNhanvien = new System.Windows.Forms.TabPage();
            this.panel7 = new System.Windows.Forms.Panel();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.btnXemNV = new System.Windows.Forms.Button();
            this.btnThemNV = new System.Windows.Forms.Button();
            this.btnSuaNV = new System.Windows.Forms.Button();
            this.btnXoaNV = new System.Windows.Forms.Button();
            this.panel8 = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.panel9 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.lblNgay = new System.Windows.Forms.Label();
            this.panel11 = new System.Windows.Forms.Panel();
            this.panel12 = new System.Windows.Forms.Panel();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.lblThang = new System.Windows.Forms.Label();
            this.panel13 = new System.Windows.Forms.Panel();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.lblNam = new System.Windows.Forms.Label();
            this.panel10 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.panel14 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.panel15 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.tabControl1.SuspendLayout();
            this.tbpDoanhthu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.tbpBanh.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudSoluong)).BeginInit();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudGia)).BeginInit();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.tbpNhanvien.SuspendLayout();
            this.panel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            this.panel8.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel12.SuspendLayout();
            this.panel13.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel14.SuspendLayout();
            this.panel15.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl1.Controls.Add(this.tbpDoanhthu);
            this.tabControl1.Controls.Add(this.tbpBanh);
            this.tabControl1.Controls.Add(this.tbpNhanvien);
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1490, 881);
            this.tabControl1.TabIndex = 0;
            // 
            // tbpDoanhthu
            // 
            this.tbpDoanhthu.Controls.Add(this.panel13);
            this.tbpDoanhthu.Controls.Add(this.panel12);
            this.tbpDoanhthu.Controls.Add(this.panel11);
            this.tbpDoanhthu.Controls.Add(this.dateTimePicker2);
            this.tbpDoanhthu.Controls.Add(this.label2);
            this.tbpDoanhthu.Controls.Add(this.label1);
            this.tbpDoanhthu.Controls.Add(this.dateTimePicker1);
            this.tbpDoanhthu.Controls.Add(this.btnthongke);
            this.tbpDoanhthu.Controls.Add(this.dataGridView1);
            this.tbpDoanhthu.Font = new System.Drawing.Font("Times New Roman", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbpDoanhthu.Location = new System.Drawing.Point(8, 39);
            this.tbpDoanhthu.Name = "tbpDoanhthu";
            this.tbpDoanhthu.Padding = new System.Windows.Forms.Padding(3);
            this.tbpDoanhthu.Size = new System.Drawing.Size(1474, 834);
            this.tbpDoanhthu.TabIndex = 0;
            this.tbpDoanhthu.Text = "Doanh thu";
            this.tbpDoanhthu.UseVisualStyleBackColor = true;
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Location = new System.Drawing.Point(776, 25);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(410, 39);
            this.dateTimePicker2.TabIndex = 6;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 13.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(6, 25);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(142, 40);
            this.label2.TabIndex = 5;
            this.label2.Text = "Từ ngày";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 13.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(602, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(152, 40);
            this.label1.TabIndex = 3;
            this.label1.Text = "đến ngày";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(154, 25);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(410, 39);
            this.dateTimePicker1.TabIndex = 2;
            this.dateTimePicker1.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // btnthongke
            // 
            this.btnthongke.BackColor = System.Drawing.Color.Silver;
            this.btnthongke.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnthongke.Location = new System.Drawing.Point(1310, 20);
            this.btnthongke.Name = "btnthongke";
            this.btnthongke.Size = new System.Drawing.Size(158, 44);
            this.btnthongke.TabIndex = 1;
            this.btnthongke.Text = "Thống kê";
            this.btnthongke.UseVisualStyleBackColor = false;
            this.btnthongke.Click += new System.EventHandler(this.btnthongke_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(6, 100);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 82;
            this.dataGridView1.RowTemplate.Height = 33;
            this.dataGridView1.Size = new System.Drawing.Size(1084, 728);
            this.dataGridView1.TabIndex = 0;
            // 
            // tbpBanh
            // 
            this.tbpBanh.Controls.Add(this.panel6);
            this.tbpBanh.Controls.Add(this.panel5);
            this.tbpBanh.Controls.Add(this.btnXoa);
            this.tbpBanh.Controls.Add(this.btnSua);
            this.tbpBanh.Controls.Add(this.btnThem);
            this.tbpBanh.Controls.Add(this.btnXem);
            this.tbpBanh.Controls.Add(this.panel4);
            this.tbpBanh.Controls.Add(this.panel3);
            this.tbpBanh.Controls.Add(this.panel2);
            this.tbpBanh.Controls.Add(this.panel1);
            this.tbpBanh.Controls.Add(this.dataGridView2);
            this.tbpBanh.Font = new System.Drawing.Font("Times New Roman", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbpBanh.Location = new System.Drawing.Point(8, 39);
            this.tbpBanh.Name = "tbpBanh";
            this.tbpBanh.Padding = new System.Windows.Forms.Padding(3);
            this.tbpBanh.Size = new System.Drawing.Size(1474, 834);
            this.tbpBanh.TabIndex = 1;
            this.tbpBanh.Text = "Bánh";
            this.tbpBanh.UseVisualStyleBackColor = true;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.lblVoucher);
            this.panel6.Controls.Add(this.txtVoucher);
            this.panel6.Location = new System.Drawing.Point(919, 641);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(552, 121);
            this.panel6.TabIndex = 9;
            // 
            // lblVoucher
            // 
            this.lblVoucher.AutoSize = true;
            this.lblVoucher.BackColor = System.Drawing.Color.LightGray;
            this.lblVoucher.Font = new System.Drawing.Font("Times New Roman", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVoucher.Location = new System.Drawing.Point(416, 44);
            this.lblVoucher.Name = "lblVoucher";
            this.lblVoucher.Size = new System.Drawing.Size(111, 31);
            this.lblVoucher.TabIndex = 2;
            this.lblVoucher.Text = "Voucher";
            // 
            // txtVoucher
            // 
            this.txtVoucher.Location = new System.Drawing.Point(14, 42);
            this.txtVoucher.Name = "txtVoucher";
            this.txtVoucher.Size = new System.Drawing.Size(369, 39);
            this.txtVoucher.TabIndex = 0;
            this.txtVoucher.TextChanged += new System.EventHandler(this.txtVoucher_TextChanged);
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.nudSoluong);
            this.panel5.Controls.Add(this.lblSoluong);
            this.panel5.Location = new System.Drawing.Point(919, 514);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(549, 121);
            this.panel5.TabIndex = 8;
            // 
            // nudSoluong
            // 
            this.nudSoluong.Location = new System.Drawing.Point(15, 44);
            this.nudSoluong.Name = "nudSoluong";
            this.nudSoluong.Size = new System.Drawing.Size(395, 39);
            this.nudSoluong.TabIndex = 5;
            this.nudSoluong.ValueChanged += new System.EventHandler(this.nudSoluong_ValueChanged);
            // 
            // lblSoluong
            // 
            this.lblSoluong.AutoSize = true;
            this.lblSoluong.BackColor = System.Drawing.Color.LightGray;
            this.lblSoluong.Font = new System.Drawing.Font("Times New Roman", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSoluong.Location = new System.Drawing.Point(416, 45);
            this.lblSoluong.Name = "lblSoluong";
            this.lblSoluong.Size = new System.Drawing.Size(117, 31);
            this.lblSoluong.TabIndex = 3;
            this.lblSoluong.Text = "Số lượng";
            // 
            // btnXoa
            // 
            this.btnXoa.BackColor = System.Drawing.Color.LightGray;
            this.btnXoa.Location = new System.Drawing.Point(621, 15);
            this.btnXoa.Name = "btnXoa";
            this.btnXoa.Size = new System.Drawing.Size(134, 89);
            this.btnXoa.TabIndex = 7;
            this.btnXoa.Text = "Xóa";
            this.btnXoa.UseVisualStyleBackColor = false;
            // 
            // btnSua
            // 
            this.btnSua.BackColor = System.Drawing.Color.LightGray;
            this.btnSua.Location = new System.Drawing.Point(399, 15);
            this.btnSua.Name = "btnSua";
            this.btnSua.Size = new System.Drawing.Size(134, 89);
            this.btnSua.TabIndex = 6;
            this.btnSua.Text = "Sửa";
            this.btnSua.UseVisualStyleBackColor = false;
            // 
            // btnThem
            // 
            this.btnThem.BackColor = System.Drawing.Color.LightGray;
            this.btnThem.Location = new System.Drawing.Point(199, 15);
            this.btnThem.Name = "btnThem";
            this.btnThem.Size = new System.Drawing.Size(134, 89);
            this.btnThem.TabIndex = 5;
            this.btnThem.Text = "Thêm";
            this.btnThem.UseVisualStyleBackColor = false;
            // 
            // btnXem
            // 
            this.btnXem.BackColor = System.Drawing.Color.LightGray;
            this.btnXem.Location = new System.Drawing.Point(3, 15);
            this.btnXem.Name = "btnXem";
            this.btnXem.Size = new System.Drawing.Size(134, 89);
            this.btnXem.TabIndex = 4;
            this.btnXem.Text = "Xem";
            this.btnXem.UseVisualStyleBackColor = false;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.nudGia);
            this.panel4.Controls.Add(this.LblGia);
            this.panel4.Location = new System.Drawing.Point(919, 387);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(549, 121);
            this.panel4.TabIndex = 3;
            // 
            // nudGia
            // 
            this.nudGia.Location = new System.Drawing.Point(14, 40);
            this.nudGia.Name = "nudGia";
            this.nudGia.Size = new System.Drawing.Size(396, 39);
            this.nudGia.TabIndex = 4;
            // 
            // LblGia
            // 
            this.LblGia.AutoSize = true;
            this.LblGia.BackColor = System.Drawing.Color.LightGray;
            this.LblGia.Font = new System.Drawing.Font("Times New Roman", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblGia.Location = new System.Drawing.Point(416, 41);
            this.LblGia.Name = "LblGia";
            this.LblGia.Size = new System.Drawing.Size(108, 31);
            this.LblGia.TabIndex = 3;
            this.LblGia.Text = "Giá tiền";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.lblTenbanh);
            this.panel3.Controls.Add(this.txtName);
            this.panel3.Location = new System.Drawing.Point(919, 260);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(552, 121);
            this.panel3.TabIndex = 3;
            // 
            // lblTenbanh
            // 
            this.lblTenbanh.AutoSize = true;
            this.lblTenbanh.BackColor = System.Drawing.Color.LightGray;
            this.lblTenbanh.Font = new System.Drawing.Font("Times New Roman", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTenbanh.Location = new System.Drawing.Point(399, 42);
            this.lblTenbanh.Name = "lblTenbanh";
            this.lblTenbanh.Size = new System.Drawing.Size(125, 31);
            this.lblTenbanh.TabIndex = 2;
            this.lblTenbanh.Text = "Tên bánh";
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(14, 40);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(369, 39);
            this.txtName.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.lblId);
            this.panel2.Controls.Add(this.txtId);
            this.panel2.Location = new System.Drawing.Point(919, 133);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(549, 121);
            this.panel2.TabIndex = 3;
            // 
            // lblId
            // 
            this.lblId.AutoSize = true;
            this.lblId.BackColor = System.Drawing.Color.LightGray;
            this.lblId.Font = new System.Drawing.Font("Times New Roman", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblId.Location = new System.Drawing.Point(405, 41);
            this.lblId.Name = "lblId";
            this.lblId.Size = new System.Drawing.Size(119, 31);
            this.lblId.TabIndex = 1;
            this.lblId.Text = "Mã bánh";
            // 
            // txtId
            // 
            this.txtId.Location = new System.Drawing.Point(14, 39);
            this.txtId.Name = "txtId";
            this.txtId.Size = new System.Drawing.Size(369, 39);
            this.txtId.TabIndex = 0;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.textBox1);
            this.panel1.Location = new System.Drawing.Point(919, 6);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(549, 121);
            this.panel1.TabIndex = 2;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.LightGray;
            this.button1.Font = new System.Drawing.Font("Times New Roman", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(403, 25);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(123, 66);
            this.button1.TabIndex = 1;
            this.button1.Text = "Tìm";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.SystemColors.Menu;
            this.textBox1.Location = new System.Drawing.Point(14, 41);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(369, 39);
            this.textBox1.TabIndex = 0;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(6, 126);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowHeadersWidth = 82;
            this.dataGridView2.RowTemplate.Height = 33;
            this.dataGridView2.Size = new System.Drawing.Size(907, 716);
            this.dataGridView2.TabIndex = 0;
            // 
            // tbpNhanvien
            // 
            this.tbpNhanvien.Controls.Add(this.panel7);
            this.tbpNhanvien.Location = new System.Drawing.Point(8, 39);
            this.tbpNhanvien.Name = "tbpNhanvien";
            this.tbpNhanvien.Padding = new System.Windows.Forms.Padding(3);
            this.tbpNhanvien.Size = new System.Drawing.Size(1474, 834);
            this.tbpNhanvien.TabIndex = 2;
            this.tbpNhanvien.Text = "Nhân viên";
            this.tbpNhanvien.UseVisualStyleBackColor = true;
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.panel15);
            this.panel7.Controls.Add(this.panel14);
            this.panel7.Controls.Add(this.panel10);
            this.panel7.Controls.Add(this.panel9);
            this.panel7.Controls.Add(this.panel8);
            this.panel7.Controls.Add(this.btnXoaNV);
            this.panel7.Controls.Add(this.btnSuaNV);
            this.panel7.Controls.Add(this.btnThemNV);
            this.panel7.Controls.Add(this.btnXemNV);
            this.panel7.Controls.Add(this.dataGridView3);
            this.panel7.Location = new System.Drawing.Point(3, 3);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(1471, 828);
            this.panel7.TabIndex = 0;
            // 
            // dataGridView3
            // 
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Location = new System.Drawing.Point(3, 109);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.RowHeadersWidth = 82;
            this.dataGridView3.RowTemplate.Height = 33;
            this.dataGridView3.Size = new System.Drawing.Size(907, 716);
            this.dataGridView3.TabIndex = 1;
            // 
            // btnXemNV
            // 
            this.btnXemNV.BackColor = System.Drawing.Color.LightGray;
            this.btnXemNV.Location = new System.Drawing.Point(3, 14);
            this.btnXemNV.Name = "btnXemNV";
            this.btnXemNV.Size = new System.Drawing.Size(134, 89);
            this.btnXemNV.TabIndex = 5;
            this.btnXemNV.Text = "Xem";
            this.btnXemNV.UseVisualStyleBackColor = false;
            // 
            // btnThemNV
            // 
            this.btnThemNV.BackColor = System.Drawing.Color.LightGray;
            this.btnThemNV.Location = new System.Drawing.Point(185, 14);
            this.btnThemNV.Name = "btnThemNV";
            this.btnThemNV.Size = new System.Drawing.Size(134, 89);
            this.btnThemNV.TabIndex = 6;
            this.btnThemNV.Text = "Thêm";
            this.btnThemNV.UseVisualStyleBackColor = false;
            // 
            // btnSuaNV
            // 
            this.btnSuaNV.BackColor = System.Drawing.Color.LightGray;
            this.btnSuaNV.Location = new System.Drawing.Point(371, 14);
            this.btnSuaNV.Name = "btnSuaNV";
            this.btnSuaNV.Size = new System.Drawing.Size(134, 89);
            this.btnSuaNV.TabIndex = 7;
            this.btnSuaNV.Text = "Sửa";
            this.btnSuaNV.UseVisualStyleBackColor = false;
            // 
            // btnXoaNV
            // 
            this.btnXoaNV.BackColor = System.Drawing.Color.LightGray;
            this.btnXoaNV.Location = new System.Drawing.Point(560, 14);
            this.btnXoaNV.Name = "btnXoaNV";
            this.btnXoaNV.Size = new System.Drawing.Size(134, 89);
            this.btnXoaNV.TabIndex = 8;
            this.btnXoaNV.Text = "Xóa";
            this.btnXoaNV.UseVisualStyleBackColor = false;
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.button2);
            this.panel8.Controls.Add(this.textBox2);
            this.panel8.Location = new System.Drawing.Point(916, 3);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(549, 121);
            this.panel8.TabIndex = 9;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.LightGray;
            this.button2.Font = new System.Drawing.Font("Times New Roman", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(403, 25);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(123, 66);
            this.button2.TabIndex = 1;
            this.button2.Text = "Tìm";
            this.button2.UseVisualStyleBackColor = false;
            // 
            // textBox2
            // 
            this.textBox2.BackColor = System.Drawing.SystemColors.Menu;
            this.textBox2.Location = new System.Drawing.Point(14, 41);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(369, 31);
            this.textBox2.TabIndex = 0;
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.label3);
            this.panel9.Controls.Add(this.textBox3);
            this.panel9.Location = new System.Drawing.Point(916, 130);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(549, 121);
            this.panel9.TabIndex = 10;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.LightGray;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(8, 13);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(180, 31);
            this.label3.TabIndex = 1;
            this.label3.Text = "Mã Nhân viên";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(14, 62);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(517, 31);
            this.textBox3.TabIndex = 0;
            this.textBox3.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(24, 58);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(329, 39);
            this.textBox5.TabIndex = 7;
            // 
            // lblNgay
            // 
            this.lblNgay.AutoSize = true;
            this.lblNgay.Location = new System.Drawing.Point(18, 14);
            this.lblNgay.Name = "lblNgay";
            this.lblNgay.Size = new System.Drawing.Size(194, 31);
            this.lblNgay.TabIndex = 8;
            this.lblNgay.Text = "Doanh thu ngày:";
            this.lblNgay.Click += new System.EventHandler(this.lblNgay_Click);
            // 
            // panel11
            // 
            this.panel11.Controls.Add(this.textBox5);
            this.panel11.Controls.Add(this.lblNgay);
            this.panel11.Location = new System.Drawing.Point(1099, 100);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(372, 112);
            this.panel11.TabIndex = 9;
            // 
            // panel12
            // 
            this.panel12.Controls.Add(this.textBox6);
            this.panel12.Controls.Add(this.lblThang);
            this.panel12.Location = new System.Drawing.Point(1099, 240);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(372, 112);
            this.panel12.TabIndex = 10;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(24, 58);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(329, 39);
            this.textBox6.TabIndex = 7;
            // 
            // lblThang
            // 
            this.lblThang.AutoSize = true;
            this.lblThang.Location = new System.Drawing.Point(18, 14);
            this.lblThang.Name = "lblThang";
            this.lblThang.Size = new System.Drawing.Size(203, 31);
            this.lblThang.TabIndex = 8;
            this.lblThang.Text = "Doanh thu tháng:";
            // 
            // panel13
            // 
            this.panel13.Controls.Add(this.textBox7);
            this.panel13.Controls.Add(this.lblNam);
            this.panel13.Location = new System.Drawing.Point(1102, 368);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(372, 112);
            this.panel13.TabIndex = 11;
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(24, 58);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(329, 39);
            this.textBox7.TabIndex = 7;
            // 
            // lblNam
            // 
            this.lblNam.AutoSize = true;
            this.lblNam.Location = new System.Drawing.Point(18, 14);
            this.lblNam.Name = "lblNam";
            this.lblNam.Size = new System.Drawing.Size(189, 31);
            this.lblNam.TabIndex = 8;
            this.lblNam.Text = "Doanh thu năm:";
            // 
            // panel10
            // 
            this.panel10.Controls.Add(this.label4);
            this.panel10.Controls.Add(this.textBox4);
            this.panel10.Location = new System.Drawing.Point(916, 257);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(549, 121);
            this.panel10.TabIndex = 11;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.LightGray;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(8, 13);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(181, 31);
            this.label4.TabIndex = 1;
            this.label4.Text = "Tên nhân viên";
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(14, 62);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(517, 31);
            this.textBox4.TabIndex = 0;
            // 
            // panel14
            // 
            this.panel14.Controls.Add(this.label5);
            this.panel14.Controls.Add(this.textBox8);
            this.panel14.Location = new System.Drawing.Point(916, 384);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(549, 121);
            this.panel14.TabIndex = 12;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.LightGray;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(8, 13);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(180, 31);
            this.label5.TabIndex = 1;
            this.label5.Text = "Mã Nhân viên";
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(14, 62);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(517, 31);
            this.textBox8.TabIndex = 0;
            // 
            // panel15
            // 
            this.panel15.Controls.Add(this.label6);
            this.panel15.Controls.Add(this.textBox9);
            this.panel15.Location = new System.Drawing.Point(916, 511);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(549, 121);
            this.panel15.TabIndex = 13;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.LightGray;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(8, 13);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(180, 31);
            this.label6.TabIndex = 1;
            this.label6.Text = "Mã Nhân viên";
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(14, 62);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(517, 31);
            this.textBox9.TabIndex = 0;
            // 
            // fAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1514, 905);
            this.Controls.Add(this.tabControl1);
            this.Name = "fAdmin";
            this.Text = "Admin";
            this.tabControl1.ResumeLayout(false);
            this.tbpDoanhthu.ResumeLayout(false);
            this.tbpDoanhthu.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.tbpBanh.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudSoluong)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudGia)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.tbpNhanvien.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.panel12.ResumeLayout(false);
            this.panel12.PerformLayout();
            this.panel13.ResumeLayout(false);
            this.panel13.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.panel14.ResumeLayout(false);
            this.panel14.PerformLayout();
            this.panel15.ResumeLayout(false);
            this.panel15.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tbpDoanhthu;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Button btnthongke;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TabPage tbpBanh;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.NumericUpDown nudSoluong;
        private System.Windows.Forms.Label lblSoluong;
        private System.Windows.Forms.Button btnXoa;
        private System.Windows.Forms.Button btnSua;
        private System.Windows.Forms.Button btnThem;
        private System.Windows.Forms.Button btnXem;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.NumericUpDown nudGia;
        private System.Windows.Forms.Label LblGia;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label lblTenbanh;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lblId;
        private System.Windows.Forms.TextBox txtId;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label lblVoucher;
        private System.Windows.Forms.TextBox txtVoucher;
        private System.Windows.Forms.TabPage tbpNhanvien;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button btnXoaNV;
        private System.Windows.Forms.Button btnSuaNV;
        private System.Windows.Forms.Button btnThemNV;
        private System.Windows.Forms.Button btnXemNV;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label lblNgay;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.Label lblNam;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Label lblThang;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox4;
    }
}